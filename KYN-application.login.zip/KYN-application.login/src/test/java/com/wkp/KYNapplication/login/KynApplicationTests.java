package com.wkp.KYNapplication.login;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KynApplicationTests {

	@Test
	void contextLoads() {
	}

}
