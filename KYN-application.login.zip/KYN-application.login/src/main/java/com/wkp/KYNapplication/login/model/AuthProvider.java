package com.wkp.KYNapplication.login.model;


public enum  AuthProvider {
    local,
    google,
    facebook

}